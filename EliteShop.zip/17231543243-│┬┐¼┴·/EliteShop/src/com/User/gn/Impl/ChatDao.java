package com.User.gn.Impl;

import java.util.List;

import com.User.pojo.User;

public interface ChatDao {
	public void add(User user);
	
	public void delete(int id);
	
	public void update(User user);
	
	public User Load(int id);
	
	public User Load(String username);
	
	public List<User> load();
	
	public int count(String tableName,String leixing,String type);
	
	public List addres(String table,String type,String leixing,String clumn);
}
