package com.User.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.omg.CORBA.UserException;

import com.User.gn.Impl.ChatDao;
import com.User.pojo.User;
import com.jdbc.ConnectSQL;

public class Login implements ChatDao{
	private Connection con;
	private ResultSet rs;
	private PreparedStatement ptstmt;
	private ConnectSQL sc=new ConnectSQL();
 String sql;
	public void add(User user) {
		// TODO Auto-generated method stub
		con=sc.getConnection();
		sql="select count(*) from Usertable where UserName=?";
		ptstmt=null;
		rs=null;
		try {
			ptstmt=con.prepareStatement(sql);
			ptstmt.setString(1,user.getUserName());
			rs=ptstmt.executeQuery();
			sql="insert into Usertable(UserName,PassWord) values(?,?)";
			ptstmt=con.prepareStatement(sql);
			ptstmt.setString(1, user.getUserName());
			ptstmt.setString(2, user.getPassWord());
			ptstmt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	


	public void delete(int id) {
		// TODO Auto-generated method stub
		 //������ӵĶ���
        con=sc.getConnection();
        //׼��sql���
        sql="delete from Usertable where UserID=?";
        //������䴫�����
        ptstmt=null;
        try 
        {
            
        	ptstmt=con.prepareStatement(sql);
        	ptstmt.setInt(1, id);
        	ptstmt.executeUpdate();
            
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
            
        }
		
	}
	public void update(User user) {
		// TODO Auto-generated method stub
		//������ӵĶ���
        con=sc.getConnection();
        //׼��sql���
        sql="delete from Usertable where UserID=?";
        //������䴫�����
        ptstmt=null;
        try 
        {
        	ptstmt=con.prepareStatement(sql);
        	ptstmt.setString(1, user.getUserName());
        	ptstmt.setString(2, user.getPassWord());
        	ptstmt.setInt(3, user.getUserID());
        	ptstmt.executeUpdate();
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
       
		
	}


	public List<User> load() {
		//������ӵĶ���
        con=sc.getConnection();
        //׼��sql���
        sql="delete from Usertable where UserID=?";
        //������䴫�����
        ptstmt=null;
        rs=null;
        List<User> users=new ArrayList<User>();
        User user=null;
        try 
        {
        	ptstmt=con.prepareStatement(sql);
            rs=ptstmt.executeQuery();
            while(rs.next()) 
            {
                user=new User();
                user.setUserID(rs.getInt("UserID"));
                user.setUserName(rs.getString("UserName"));
                user.setPassWord(rs.getString("PassWord"));
                users.add(user);
            }
            
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
        return users;
	}



	public User Load(int id) {
		// TODO Auto-generated method stub
		//������ӵĶ���
        con=sc.getConnection();
        //׼��sql���
        sql="select * from Usertable where UserID=?";
        //������䴫�����
        ptstmt=null;
        rs=null;
        User user=null;
        try 
        {
        	ptstmt=con.prepareStatement(sql);
        	ptstmt.setInt(1, id);
            rs=ptstmt.executeQuery();
            while(rs.next()) 
            {
                user=new User();
                user.setUserID(id);
                user.setUserName(rs.getString("UserName"));
                user.setPassWord(rs.getString("PassWord"));
               
            }        
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
		return user;
	}



	public User Load(String username) {
		// TODO Auto-generated method stub
			con=sc.getConnection();
	        //׼��sql���
	        sql="select * from Usertable where UserName=?";
	        //������䴫�����
	        ptstmt=null;
	        rs=null;
	        User user=null;
	        try 
	        {
	        	ptstmt=con.prepareStatement(sql);
	        	ptstmt.setString(1, username);
	            rs=ptstmt.executeQuery();
	            while(rs.next()) 
	            {
	                user=new User();
	                user.setUserID(rs.getInt("UserID"));
	                user.setUserName(username);
	                user.setPassWord(rs.getString("PassWord"));
	            }
	        }
	        catch(SQLException e) 
	        {
	        e.printStackTrace();
	        }
		return user;
	}
	//��������Ƿ����
	 public boolean check(User user) 
	    {
		 boolean flag=false;
	        con=sc.getConnection();
	        sql="select * from Usertable where username=?";
	        ptstmt= null;
	        rs=null;
	        try 
	        {
	        	ptstmt=con.prepareStatement(sql);
	        	ptstmt.setString(1,user.getUserName());
	            rs=ptstmt.executeQuery();
	           
	            while(rs.next()) 
	            {
//	            	System.out.println(rs.getString("PassWord"));
//	 	            System.out.println(user.getPassWord().toString().trim());
//	            	System.out.println(rs.getString("PassWord").length());
//	 	            System.out.println(user.getPassWord().toString().trim().length());
	                if(rs.getString("PassWord").equals(user.getPassWord().toString().trim())) 
	                {
	                    flag=true;
	                    break;
	                }
	            }
	        } 
	        catch (SQLException e) 
	        {
	            e.printStackTrace();
	        }
	        return flag;
	    }


//��ѯ������Ƭ��Ŀ
	public int count(String tableName,String leixing, String type) {
		// TODO Auto-generated method stub
		
			con=sc.getConnection();
        //׼��sql���
//			sql="select * from Goods where type like "+"'%"+s+"%'";
			sql="select count(*) as 'count' from " +tableName+ " where "+leixing+"=?";
        //������䴫�����
			ptstmt=null;
			rs=null;
			int count=0;
			
		  try 
	        {
	        	ptstmt=con.prepareStatement(sql);
	        	ptstmt.setString(1, type);
	            rs=ptstmt.executeQuery();
	            while(rs.next()) 
	            {
	                count=rs.getInt("count");
	               
	            }        
	        }
	        catch(SQLException e) 
	        {
	            e.printStackTrace();
	        }
			return count;
	}
//��ȡ��Ƭ��ַ	 
public List addres(String table,String type,String leixing,String clumn) {
	// TODO Auto-generated method stub
	con=sc.getConnection();
    //׼��sql���
		sql="select * from " +table+ " where "+leixing+"=? ";
    //������䴫�����
		ptstmt=null;
		rs=null;
		int count=1;
		List list=new ArrayList();
		try 
        {
        	ptstmt=con.prepareStatement(sql);
        	ptstmt.setString(1, type);
            rs=ptstmt.executeQuery();
            
          
            while(rs.next()) 
            {
                	list.add(rs.getString(clumn));   
            }        
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
		return list;
		}



	//����Ա������Ƭ
//����
public void adminInsert(String name,String imagesAddress,String type,String introduct,String price) {
	// TODO Auto-generated method stub
	con=sc.getConnection();
	sql="insert into Goods(name,imagesAddress,type,introduct,price) values(?,?,?,?,?)";
	ptstmt=null;
	rs=null;
	try {
		ptstmt=con.prepareStatement(sql);
		ptstmt.setString(1,name);
		ptstmt.setString(2,imagesAddress);
		ptstmt.setString(3,type);
		ptstmt.setString(4,introduct);
		ptstmt.setString(5,price);
//		rs=ptstmt.executeQuery();
		ptstmt.executeUpdate();
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

//ɾ��
public void adminDelete(String GoodsID) {
	// TODO Auto-generated method stub
	con=sc.getConnection();
	sql="delete from Goods where GoodsID=?";
	ptstmt=null;
	rs=null;
	try {
		ptstmt=con.prepareStatement(sql);
		ptstmt.setString(1,GoodsID);
		
		
//		rs=ptstmt.executeQuery();
		ptstmt.executeUpdate();
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

//����
public void adminUpdate(String name,String imagesAddress,String type,String introduct,String GoodsID) {
	// TODO Auto-generated method stub
	con=sc.getConnection();
	sql="update  Goods set name=?,imagesAddress=?,type=?,introduct=? where GoodsID=?";
	ptstmt=null;
	rs=null;
	try {
		ptstmt=con.prepareStatement(sql);
		ptstmt.setString(1,name);
		ptstmt.setString(2,imagesAddress);
		ptstmt.setString(3,type);
		ptstmt.setString(4,introduct);
		ptstmt.setString(5,GoodsID);
		
//		rs=ptstmt.executeQuery();
		ptstmt.executeUpdate();
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
public void carAdd (int UserID,int GoodsID,String imageAdress,String name,String price) {
	// TODO Auto-generated method stub
	con=sc.getConnection();
	sql="insert into Car (UserID,GoodsID,imageAdress,name,price) values(?,?,?,?,?)";
	ptstmt=null;
	rs=null;
	try {
		ptstmt=con.prepareStatement(sql);
		ptstmt.setInt(1,UserID);
		ptstmt.setInt(2,GoodsID);
		ptstmt.setString(3,imageAdress);
		ptstmt.setString(4,name);
		ptstmt.setString(5,price);
//		rs=ptstmt.executeQuery();
		ptstmt.executeUpdate();
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
public int selectCar(String type) {
	// TODO Auto-generated method stub
	con=sc.getConnection();
    //׼��sql���
		sql="select * from Usertable where UserName=?";
    //������䴫�����
		ptstmt=null;
		rs=null;
		int count=1;
		int s=0;
		try 
        {
        	ptstmt=con.prepareStatement(sql);
        	ptstmt.setString(1, type);
            rs=ptstmt.executeQuery();
            
          
            while(rs.next()) 
            {
                	s=rs.getInt("UserID");   
            }        
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
		return s;
		}
public void OrderAdd (String UserName,int CountPrice,String GoodsAddess,String phone,String LinkName) {
	// TODO Auto-generated method stub
	con=sc.getConnection();
	sql="insert into Ordertable (UserName,CountPrice,GoodsAddress,phone,LinkName) values(?,?,?,?,?)";
	ptstmt=null;
	rs=null;
	try {
		ptstmt=con.prepareStatement(sql);
		ptstmt.setString(1,UserName);
		ptstmt.setInt(2,CountPrice);
		ptstmt.setString(3,GoodsAddess);
		ptstmt.setString(4,phone);
		ptstmt.setString(5,LinkName);
//		rs=ptstmt.executeQuery();
		ptstmt.executeUpdate();
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
//��չ��ﳵ
public void deleteCar(String UserID) {
	// TODO Auto-generated method stub
	con=sc.getConnection();
	sql="delete from Car where UserID=?";
	ptstmt=null;
	rs=null;
	try {
		ptstmt=con.prepareStatement(sql);
		ptstmt.setString(1,UserID);
		
		
//		rs=ptstmt.executeQuery();
		ptstmt.executeUpdate();
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
//ģ����ѯ
//��ȡ��Ƭ��ַ	 
public List addres1(String s,String clumn) {
	// TODO Auto-generated method stub
	con=sc.getConnection();
    //׼��sql���
		sql="select * from Goods where type like "+"'%"+s+"%'";
    //������䴫�����
		ptstmt=null;
		rs=null;
		int count=1;
		List list=new ArrayList();
		try 
        {
        	ptstmt=con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
        	
            rs=ptstmt.executeQuery();
            
         
            while(rs.next()) 
            {
                	list.add(rs.getString(clumn));   
            }        
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
		return list;
		}

public int count1(String tableName,String leixing, String type) {
	// TODO Auto-generated method stub
	
		con=sc.getConnection();
    //׼��sql���
//		sql="select * from Goods where type like "+"'%"+s+"%'";
		sql="select count(*) as 'count' from " +tableName+ " where "+leixing+" like "+"'%"+type+"%'";
    //������䴫�����
		ptstmt=null;
		rs=null;
		int count=0;
		
	  try 
        {
        	ptstmt=con.prepareStatement(sql);
        	
            rs=ptstmt.executeQuery();
            while(rs.next()) 
            {
                count=rs.getInt("count");
               
            }        
        }
        catch(SQLException e) 
        {
            e.printStackTrace();
        }
		return count;
}

}
