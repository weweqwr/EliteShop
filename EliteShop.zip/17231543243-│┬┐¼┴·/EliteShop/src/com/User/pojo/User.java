package com.User.pojo;

public class User {
	public int UserID;
	public String UserName;
	public String PassWord;
	public String type;
	public String imagesAddress;
	public String name;
	public int price;
	public int SumGoods;
	public int getUserID() {
		return UserID;
	}
	public void setUserID(int userID) {
		UserID = userID;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassWord() {
		return PassWord;
	}
	public void setPassWord(String passWord) {
		PassWord = passWord;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getImagesAddress() {
		return imagesAddress;
	}
	public void setImagesAddress(String imagesAddress) {
		this.imagesAddress = imagesAddress;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getSumGoods() {
		return SumGoods;
	}
	public void setSumGoods(int sumGoods) {
		SumGoods = sumGoods;
	}
}
