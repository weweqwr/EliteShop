package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//����sql server���ݿ�
public class ConnectSQL {
	private Connection con;
	private static final String USERNAME = "sa";
	private static final String PASSWORD = "123654";
	private static final String url="jdbc:sqlserver://localhost:1433;DatabaseName=ChatDatabase";
	
	public Connection getConnection(){
		try {
			//1.������������
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			//2.������ݿ������
			con = DriverManager.getConnection(url, USERNAME, PASSWORD);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return con;
	}

}
